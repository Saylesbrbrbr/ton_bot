# bot.py
# Telegram bot (aiogram v3) — заказы + админ-панель с кнопкой для изменения курсов (TON, USDT, Stars)
# Хранение заказов: SQLite (orders.db)
# Курсы сохраняются в rates.json

import asyncio
import json
import logging
import os
from typing import Optional

import aiosqlite
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command, Text
from aiogram.types import (
    ReplyKeyboardMarkup, KeyboardButton,
    InlineKeyboardMarkup, InlineKeyboardButton
)

# ---------- config (create config.py with TOKEN and ADMIN_ID) ----------
try:
    from config import TOKEN, ADMIN_ID
except Exception:
    TOKEN = "PUT_YOUR_TOKEN_IN_config.py"
    ADMIN_ID = 8267148211

# ---------- logging ----------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------- init bot ----------
bot = Bot(token=TOKEN)
dp = Dispatcher()

# ---------- DB / files ----------
DB_PATH = "orders.db"
RATES_PATH = "rates.json"

DEFAULT_RATES = {
    "TON": 180.0,    # руб / 1 TON
    "USDT": 100.0,   # руб / 1 USDT
    "STAR": 1.7      # руб / 1 Star
}

MIN_TON = 3.0
MIN_USDT = 7.0
MIN_STARS = 50
STARS_STEP = 50

# pending states
pending_user = {}          # user_id -> {"action": "...", "meta": {...}}
pending_admin_rate = {}    # admin_id -> "TON" / "USDT" / "STAR"

# ---------- rates helpers ----------
def load_rates() -> dict:
    if not os.path.exists(RATES_PATH):
        save_rates(DEFAULT_RATES)
        return DEFAULT_RATES.copy()
    try:
        with open(RATES_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        # ensure keys
        for k, v in DEFAULT_RATES.items():
            if k not in data:
                data[k] = v
        return data
    except Exception as e:
        logger.exception("Failed to load rates.json, using defaults")
        return DEFAULT_RATES.copy()

def save_rates(rates: dict):
    with open(RATES_PATH, "w", encoding="utf-8") as f:
        json.dump(rates, f, ensure_ascii=False, indent=2)

# load once
RATES = load_rates()

# ---------- DB helpers ----------
CREATE_USERS = """
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    last_name TEXT,
    started_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
"""

CREATE_ORDERS = """
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    username TEXT,
    type TEXT,
    details TEXT,
    amount TEXT,
    price_rub REAL,
    status TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
"""

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(CREATE_USERS)
        await db.execute(CREATE_ORDERS)
        await db.commit()

async def add_user_if_not_exists(user: types.User):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users (user_id, username, first_name, last_name) VALUES (?, ?, ?, ?)",
            (user.id, user.username or "", user.first_name or "", user.last_name or "")
        )
        await db.commit()

async def create_order_db(user_id:int, username:str, type_:str, details:str, amount:str, price_rub:float, status:str="Ожидание"):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "INSERT INTO orders (user_id, username, type, details, amount, price_rub, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (user_id, username or "", type_, details, amount, price_rub, status)
        )
        await db.commit()
        return cur.lastrowid

async def list_orders_admin(limit:int=200):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT id, user_id, username, type, amount, price_rub, status, created_at FROM orders ORDER BY id DESC LIMIT ?", (limit,))
        return await cur.fetchall()

async def list_users_db(limit:int=500):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT user_id, username, first_name FROM users ORDER BY started_at DESC LIMIT ?", (limit,))
        return await cur.fetchall()

async def update_order_status_db(order_id:int, new_status:str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE orders SET status=? WHERE id=?", (new_status, order_id))
        await db.commit()

async def get_order_user_id(order_id:int) -> Optional[int]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT user_id FROM orders WHERE id=?", (order_id,))
        row = await cur.fetchone()
        return row[0] if row else None

# ---------- keyboards ----------
def user_main_menu(is_admin: bool = False) -> ReplyKeyboardMarkup:
    kb = ReplyKeyboardMarkup(resize_keyboard=True)
    kb.add(KeyboardButton("💎 Купить TON"), KeyboardButton("💵 Купить USDT"))
    kb.add(KeyboardButton("⭐ Купить Stars"), KeyboardButton("🎁 Купить NFT подарок"))
    kb.add(KeyboardButton("💠 Telegram Premium"))
    if is_admin:
        kb.add(KeyboardButton("⚙ Админ-панель"))
    return kb

def premium_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("3 месяца — 1300₽", callback_data="premium:3"))
    kb.add(InlineKeyboardButton("6 месяцев — 1650₽", callback_data="premium:6"))
    kb.add(InlineKeyboardButton("12 месяцев — 2800₽", callback_data="premium:12"))
    return kb

def admin_panel_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("👥 Список пользователей", callback_data="admin:users"))
    kb.add(InlineKeyboardButton("📋 Список заказов", callback_data="admin:orders"))
    kb.add(InlineKeyboardButton("🔁 Редактировать курсы", callback_data="admin:rates"))
    kb.add(InlineKeyboardButton("📣 Рассылка", callback_data="admin:broadcast"))
    return kb

def rates_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton(f"TON — {RATES['TON']}₽", callback_data="rate:TON"))
    kb.add(InlineKeyboardButton(f"USDT — {RATES['USDT']}₽", callback_data="rate:USDT"))
    kb.add(InlineKeyboardButton(f"Star — {RATES['STAR']}₽", callback_data="rate:STAR"))
    kb.add(InlineKeyboardButton("⬅ Назад", callback_data="admin:back"))
    return kb

def order_actions_kb(order_id:int) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("Принять", callback_data=f"order_status:{order_id}:Принят"),
           InlineKeyboardButton("Выполнено", callback_data=f"order_status:{order_id}:Выполнено"))
    kb.add(InlineKeyboardButton("Отказать", callback_data=f"order_status:{order_id}:Отказ"),
           InlineKeyboardButton("Ответить клиенту", callback_data=f"order_reply:{order_id}"))
    return kb

# ---------- helpers ----------
def mention_username(username: str) -> str:
    return f"@{username}" if username else "(no username)"

# ---------- Handlers ----------
@dp.message_handler(Command(commands=["start","help"]))
async def cmd_start(message: types.Message):
    await add_user_if_not_exists(message.from_user)
    is_admin = (message.from_user.id == ADMIN_ID)
    await message.answer(
        "Привет. Выберите действие:",
        reply_markup=user_main_menu(is_admin)
    )

# User flow triggers
@dp.message_handler(Text(equals="💎 Купить TON"))
async def start_buy_ton(message: types.Message):
    pending_user[message.from_user.id] = {"action":"buy_ton"}
    await message.answer(f"Введите количество TON (минимум {MIN_TON} TON). Пример: 3 или 4.5")

@dp.message_handler(Text(equals="💵 Купить USDT"))
async def start_buy_usdt(message: types.Message):
    pending_user[message.from_user.id] = {"action":"buy_usdt"}
    await message.answer(f"Введите количество USDT (минимум {MIN_USDT} USDT). Пример: 7 или 20")

@dp.message_handler(Text(equals="⭐ Купить Stars"))
async def start_buy_stars(message: types.Message):
    pending_user[message.from_user.id] = {"action":"buy_stars"}
    await message.answer(f"Введите количество Stars (минимум {MIN_STARS}, кратно {STARS_STEP}). Цена: {RATES['STAR']}₽/шт")

@dp.message_handler(Text(equals="🎁 Купить NFT подарок"))
async def start_buy_nft(message: types.Message):
    pending_user[message.from_user.id] = {"action":"buy_nft"}
    await message.answer("Опишите NFT-подарок: площадка (Tonnel, Portal, Getgems) и что нужно (ссылка/описание).")

@dp.message_handler(Text(equals="💠 Telegram Premium"))
async def start_buy_premium(message: types.Message):
    pending_user[message.from_user.id] = {"action":"buy_premium_pending"}
    await message.answer("Выберите срок Premium:", reply_markup=premium_kb())

# premium callback
@dp.callback_query(lambda c: c.data and c.data.startswith("premium:"))
async def premium_choice(c: types.CallbackQuery):
    await add_user_if_not_exists(c.from_user)
    period = c.data.split(":",1)[1]
    prices = {"3":1300.0,"6":1650.0,"12":2800.0}
    price = prices.get(period, 1300.0)
    months = int(period)
    uid = c.from_user.id
    uname = c.from_user.username or ""
    details = f"Telegram Premium — {months} мес (выдача: подарочной ссылкой)"
    oid = await create_order_db(uid, uname, "Premium", details, f"{months} мес", price)
    # notify admin
    await bot.send_message(ADMIN_ID,
        f"🆕 Заказ #{oid}\nТип: Premium\nСрок: {months} мес\nЦена: {price}₽\nКлиент: {mention_username(uname)} ({uid})",
        reply_markup=order_actions_kb(oid)
    )
    await c.message.answer(f"✅ Заказ Premium ({months} мес) создан и передан админу. Цена: {price}₽")
    await c.answer()
    pending_user.pop(uid, None)

# Generic text handler for pending actions & quick commands
@dp.message_handler()
async def handle_all_messages(message: types.Message):
    uid = message.from_user.id
    uname = message.from_user.username or ""
    text = (message.text or "").strip()

    # Admin is changing a rate?
    if uid in pending_admin_rate:
        rate_key = pending_admin_rate[uid]
        try:
            val = float(text.replace(",","."))
            RATES[rate_key] = round(val, 4)
            save_rates(RATES)
            await message.answer(f"Курс {rate_key} обновлён: {RATES[rate_key]} ₽")
            logger.info(f"Admin {uid} set rate {rate_key} -> {RATES[rate_key]}")
        except:
            await message.answer("Неверный формат. Введите число, например: 180 или 100.5")
        pending_admin_rate.pop(uid, None)
        return

    # normal user pending flow
    state = pending_user.get(uid)
    if state:
        action = state.get("action")

        # TON
        if action == "buy_ton":
            try:
                amt = float(text.replace(",","."))
            except:
                await message.reply("❌ Неверный формат. Введите число. Пример: 3 или 4.5")
                return
            if amt < MIN_TON:
                await message.reply(f"❌ Минимум {MIN_TON} TON.")
                return
            price = round(amt * RATES["TON"], 2)
            details = f"TON пополнение: {amt} TON"
            oid = await create_order_db(uid, uname, "TON", details, f"{amt}", price)
            await message.reply(f"✅ Заказ #{oid}: {amt} TON → {price}₽. Передан админу.")
            await bot.send_message(ADMIN_ID, f"🆕 Заказ #{oid}\nТип: TON\nКол-во: {amt} TON\nЦена: {price}₽\nКлиент: {mention_username(uname)} ({uid})", reply_markup=order_actions_kb(oid))
            pending_user.pop(uid, None)
            return

        # USDT
        if action == "buy_usdt":
            try:
                amt = float(text.replace(",","."))
            except:
                await message.reply("❌ Неверный формат. Введите число. Пример: 7 или 20")
                return
            if amt < MIN_USDT:
                await message.reply(f"❌ Минимум {MIN_USDT} USDT.")
                return
            price = round(amt * RATES["USDT"], 2)
            details = f"USDT пополнение: {amt} USDT"
            oid = await create_order_db(uid, uname, "USDT", details, f"{amt}", price)
            await message.reply(f"✅ Заказ #{oid}: {amt} USDT → {price}₽. Передан админу.")
            await bot.send_message(ADMIN_ID, f"🆕 Заказ #{oid}\nТип: USDT\nКол-во: {amt} USDT\nЦена: {price}₽\nКлиент: {mention_username(uname)} ({uid})", reply_markup=order_actions_kb(oid))
            pending_user.pop(uid, None)
            return

        # Stars
        if action == "buy_stars":
            if not text.isdigit():
                await message.reply("❌ Введите целое число. Пример: 50")
                return
            n = int(text)
            if n < MIN_STARS:
                await message.reply(f"❌ Минимум {MIN_STARS} Stars.")
                return
            if n % STARS_STEP != 0:
                await message.reply(f"❌ Количество должно быть кратно {STARS_STEP}. Примеры: 50, 100, 150")
                return
            price = round(n * RATES["STAR"], 2)
            details = f"Stars: {n} шт"
            oid = await create_order_db(uid, uname, "Stars", details, f"{n}", price)
            await message.reply(f"⭐ Заказ #{oid}: {n} Stars → {price}₽. Передан админу.")
            await bot.send_message(ADMIN_ID, f"🆕 Заказ #{oid}\nТип: Stars\nКол-во: {n}\nЦена: {price}₽\nКлиент: {mention_username(uname)} ({uid})", reply_markup=order_actions_kb(oid))
            pending_user.pop(uid, None)
            return

        # NFT
        if action == "buy_nft":
            if len(text) < 3:
                await message.reply("Опишите подробнее: площадка (Tonnel/Portal/Getgems) и что нужно.")
                return
            details = text
            oid = await create_order_db(uid, uname, "NFT", details, "-", 0.0)
            await message.reply(f"🎁 Заказ #{oid} создан. Передан админу.")
            await bot.send_message(ADMIN_ID, f"🆕 Заказ #{oid}\nТип: NFT\nДетали: {details}\nКлиент: {mention_username(uname)} ({uid})", reply_markup=order_actions_kb(oid))
            pending_user.pop(uid, None)
            return

        # any other pending
        await message.reply("Неизвестный шаг. Начните заново через меню.")
        pending_user.pop(uid, None)
        return

    # No pending: try quick patterns (e.g., "TON 4.5", "USDT 10", or NFT keywords)
    parts = text.split(None,1)
    if len(parts) >= 2 and parts[0].upper() in ("TON","USDT"):
        coin = parts[0].upper()
        rest = parts[1].strip()
        # try to parse amount
        try:
            amt = float(rest.split()[0].replace(",","."))
        except:
            await message.reply("Ваш запрос передан администратору.")
            await bot.send_message(ADMIN_ID, f"📨 Новый запрос (не распарсен): {text}\nКлиент: {mention_username(uname)} ({uid})")
            return
        if coin == "TON":
            if amt < MIN_TON:
                await message.reply(f"❌ Минимум {MIN_TON} TON.")
                return
            price = round(amt * RATES["TON"], 2)
            oid = await create_order_db(uid, uname, "TON", f"TON quick {amt}", f"{amt}", price)
            await message.reply(f"✅ Заказ #{oid}: {amt} TON → {price}₽. Передан админу.")
            await bot.send_message(ADMIN_ID, f"🆕 Заказ #{oid}\nТип: TON\nКол-во: {amt} TON\nЦена: {price}₽\nКлиент: {mention_username(uname)} ({uid})", reply_markup=order_actions_kb(oid))
            return
        else:
            if amt < MIN_USDT:
                await message.reply(f"❌ Минимум {MIN_USDT} USDT.")
                return
            price = round(amt * RATES["USDT"], 2)
            oid = await create_order_db(uid, uname, "USDT", f"USDT quick {amt}", f"{amt}", price)
            await message.reply(f"✅ Заказ #{oid}: {amt} USDT → {price}₽. Передан админу.")
            await bot.send_message(ADMIN_ID, f"🆕 Заказ #{oid}\nТип: USDT\nКол-во: {amt} USDT\nЦена: {price}₽\nКлиент: {mention_username(uname)} ({uid})", reply_markup=order_actions_kb(oid))
            return

    # NFT quick detection
    low = text.lower()
    if any(k in low for k in ("tonnel","portal","getgems","nft","подарок")):
        oid = await create_order_db(uid, uname, "NFT", text, "-", 0.0)
        await message.reply(f"🎁 Заказ #{oid} создан. Передан админу.")
        await bot.send_message(ADMIN_ID, f"🆕 Заказ #{oid}\nТип: NFT\nДетали: {text}\nКлиент: {mention_username(uname)} ({uid})", reply_markup=order_actions_kb(oid))
        return

    # fallback - forward to admin
    await message.reply("Ваш запрос передан администратору.")
    await bot.send_message(ADMIN_ID, f"📨 Запрос: {text}\nКлиент: {mention_username(uname)} ({uid})")

# ---------- Admin panel ----------
@dp.message_handler(Text(equals="⚙ Админ-панель"))
async def show_admin_panel(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        return
    await message.answer("Админ-панель:", reply_markup=admin_panel_kb())

@dp.callback_query_handler(lambda c: c.data == "admin:rates")
async def admin_rates_menu(c: types.CallbackQuery):
    if c.from_user.id != ADMIN_ID:
        await c.answer("Нет доступа", show_alert=True)
        return
    # refresh rates from file
    global RATES
    RATES = load_rates()
    await c.message.answer("Текущие курсы (нажми, чтобы изменить):", reply_markup=rates_kb())
    await c.answer()

@dp.callback_query_handler(lambda c: c.data and c.data.startswith("rate:"))
async def admin_rate_select(c: types.CallbackQuery):
    if c.from_user.id != ADMIN_ID:
        await c.answer("Нет доступа", show_alert=True)
        return
    rate_key = c.data.split(":",1)[1]
    pending_admin_rate[c.from_user.id] = rate_key
    await c.message.answer(f"Введите новый курс для {rate_key} в рублях. Текущий: {RATES.get(rate_key)}₽\nПример: 180 или 100.5")
    await c.answer()

@dp.callback_query_handler(lambda c: c.data == "admin:users")
async def admin_users(c: types.CallbackQuery):
    if c.from_user.id != ADMIN_ID:
        await c.answer("Нет доступа", show_alert=True)
        return
    rows = await list_users_db(500)
    text = "Пользователи (последние):\n\n"
    for r in rows:
        text += f"• @{r[1] or '—'} — {r[0]}\n"
    await c.message.answer(text)
    await c.answer()

@dp.callback_query_handler(lambda c: c.data == "admin:orders")
async def admin_orders(c: types.CallbackQuery):
    if c.from_user.id != ADMIN_ID:
        await c.answer("Нет доступа", show_alert=True)
        return
    rows = await list_orders_admin(200)
    if not rows:
        await c.message.answer("Заказов нет.")
        await c.answer()
        return
    for r in rows:
        oid, uid, uname, typ, amount, price, status, created_at = r
        txt = f"#{oid} | {typ} | {amount} | {price}₽ | {status}\nКлиент: @{uname or '—'} ({uid})\nСоздано: {created_at}"
        await c.message.answer(txt, reply_markup=order_actions_kb(oid))
    await c.answer()

@dp.callback_query_handler(lambda c: c.data and c.data.startswith("order_status:"))
async def admin_change_order_status(c: types.CallbackQuery):
    if c.from_user.id != ADMIN_ID:
        await c.answer("Нет доступа", show_alert=True)
        return
    parts = c.data.split(":",2)
    if len(parts) != 3:
        await c.answer("Ошибка")
        return
    oid = int(parts[1]); new_status = parts[2]
    await update_order_status_db(oid, new_status)
    # notify user if possible
    user_id = await get_order_user_id(oid)
    if user_id:
        try:
            await bot.send_message(user_id, f"Статус вашего заказа #{oid} обновлён — {new_status}")
        except:
            pass
    await c.answer(f"Статус #{oid} -> {new_status}")
    # optionally remove buttons
    await c.message.edit_reply_markup(reply_markup=None)

@dp.callback_query_handler(lambda c: c.data and c.data.startswith("order_reply:"))
async def admin_order_reply_prompt(c: types.CallbackQuery):
    if c.from_user.id != ADMIN_ID:
        await c.answer("Нет доступа", show_alert=True)
        return
    oid = int(c.data.split(":",1)[1])
    await bot.send_message(ADMIN_ID, f"Отправьте ответ клиенту командой:\n/reply {oid} ТЕКСТ")
    await c.answer("Отправьте ответ через /reply ORDER_ID ТЕКСТ")

@dp.message_handler(Command(commands=["reply"]))
async def cmd_reply(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        return
    parts = message.text.split(" ",2)
    if len(parts) < 3:
        await message.reply("Использование: /reply <order_id> <текст>")
        return
    oid = int(parts[1]); text = parts[2]
    user_id = await get_order_user_id(oid)
    if not user_id:
        await message.reply("Заказ не найден.")
        return
    try:
        await bot.send_message(user_id, f"Ответ по заказу #{oid}:\n\n{text}")
        await message.reply("Отправлено.")
    except Exception as e:
        await message.reply(f"Ошибка: {e}")

@dp.message_handler(Command(commands=["add"]))
async def cmd_add(message: types.Message):
    # /add <user_id_or_@username> <type> <amount> <details...>
    if message.from_user.id != ADMIN_ID:
        return
    parts = message.text.split(" ",4)
    if len(parts) < 5:
        await message.reply("Использование: /add <user_id_or_@username> <type> <amount> <details>")
        return
    target, typ, amount, details = parts[1], parts[2], parts[3], parts[4]
    # resolve user id
    user_id = None; uname = ""
    if target.lstrip("@").isdigit():
        user_id = int(target)
    else:
        uname = target.lstrip("@")
        try:
            ch = await bot.get_chat(uname)
            user_id = ch.id
        except Exception as e:
            await message.reply(f"Не удалось найти пользователя: {e}")
            return
    oid = await create_order_db(user_id, uname, typ, details, amount, 0.0)
    await message.reply(f"Заказ #{oid} создан для {mention_username(uname)} ({user_id}).")
    try:
        await bot.send_message(user_id, f"Вам добавлен заказ #{oid} от администратора. Ожидайте.")
    except:
        pass

@dp.message_handler(Command(commands=["broadcast"]))
async def cmd_broadcast(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        return
    text = message.text.partition(" ")[2]
    if not text:
        await message.reply("Использование: /broadcast текст")
        return
    rows = await list_users_db(10000)
    sent = 0
    for r in rows:
        try:
            await bot.send_message(r[0], text)
            sent += 1
        except:
            pass
    await message.reply(f"Рассылка отправлена примерно {sent} пользователям.")

# ---------- startup ----------
async def on_startup():
    await init_db()
    # ensure rates file present
    save_rates(RATES)
    logger.info("Startup complete. DB/Files ready.")

if __name__ == "__main__":
    asyncio.run(on_startup())
    # run polling
    from aiogram import executor
    executor.start_polling(dp, skip_updates=True)